﻿using System;

namespace Common
{
    public interface IIdentifiable
    {
        ConsoleColor IdentifyingColor { get; set; }
    }
}

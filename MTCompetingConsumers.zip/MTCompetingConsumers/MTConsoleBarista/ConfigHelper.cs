﻿using System;
using System.Configuration;

namespace MTConsoleBarista
{
    internal static class ConfigHelper
    {
        public static string RabbitMqServer
        {
            get { return ConfigurationManager.AppSettings["RabbitMQServer"]; }
        }

        public static string BaristaQueue
        {
            get { return ConfigurationManager.AppSettings["BaristaQueue"]; }
        }

        public static int Concurrency
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["Concurrency"]); }
        }

        public static int Delay
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["SleepDelay"]); }
        }
    }
}

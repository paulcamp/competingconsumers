﻿using System;
using System.Configuration;

namespace MTConsoleCashier
{
    internal static class ConfigHelper
    {
        public static string RabbitMqServer
        {
            get { return ConfigurationManager.AppSettings["RabbitMQServer"]; }
        }

        public static string CashierQueue
        {
            get { return ConfigurationManager.AppSettings["Queue"]; }
        }

        public static int Concurrency
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["Concurrency"]); }
        }
        public static int Delay
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["SleepDelay"]); }
        }
    }
}

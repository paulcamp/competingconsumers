﻿namespace MTCompetingConsumers.Models
{
    public class EmptyModel
    {
    }
}
﻿using System.Web.Mvc;

namespace MTCompetingConsumers.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }
    }
}

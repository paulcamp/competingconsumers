﻿namespace Common
{
    public enum RequestType
    {
        Cashier = 0,
        Barista
    }
}
